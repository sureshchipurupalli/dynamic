<?php 
//echo "Hi.......";
$username="root";
$password="";
$dbname="cpanel2";
$servername="localhost";
//echo "hoho";
$conn = mysql_connect("localhost","root", "");
//echo $conn;

$db=mysql_select_db("cpanel2",$conn);



###################################################################

######### TABLE CONSTANTS 

###################################################################

/********* Table Prefix *********/

//define('SANDBOXURL', 'https://www.sandbox.paypal.com/cgi-bin/webscr');
//define('BUSINESSEMAIL', 'rk004@gmail.com');

define('TPREFIX', 'tb_');


/********* Table Names *********/

define('TBL_ADMIN','admin');
define('TBL_BANKDETAILS','bankdetails');
define('TBL_SITESETTINGS','sitesettings');

define('TBL_RECENTACTIVITIES','recentactivities');

define('TBL_BLOGPOST','blog');

define('TBL_MENU','menu');

define('TBL_SUBMENU','submenu');

define('TBL_FAQ','faq');

define('TBL_NEWSLETTERS','newsletter');
define('TBL_USERS','users');
define('TBL_VIDEOS','video');
define('TBL_COMMENTS','comments');
define('TBL_SUBSCRIBE','sub');
define('TBL_CONTACTUS','contactus');
define('TBL_SEO','seo');
define('TBL_CONTENTPAGE','contentpages');
define('TBL_LIKEDISLIKE','likes_dislikes');
define('TBL_CLIENTLIST','clientlist');
define('TBL_TESTIMONIAL','testimonial');
define('TBL_MAILFUNCTIONS','mailfunctions');
define('TBL_MAIL_TEMPLATE','mail_template');


define('TBL_SIGNUP','signup');
define('TBL_CATEGORYPAGE','categorypages');
define('TBL_SUBCATEGORYPAGE','subcategorypages');
define('TBL_PRODUCT','classifieds');
define('TBL_PRODUCT_IMAGE','classifieds_image');
define('TBL_CURRENCY','currency');
define('TBL_LANGUAGE','language');
define('TBL_JOBINVITATION','jobsinvitation');
define('TBL_POSTJOB','postjobs');
define('TBL_POSTJOBPROPOSALS','postjobsproposals');
define('TBL_FORGOT_PASSWORD','forgot_password');

define('TBL_WORKS','works');
define('TBL_CHOOSE','choose');
define('TBL_FIND','find');
define('TBL_ABOUTUS','aboutus');
define('TBL_BLOGPAGE','blogpage');

define('TBL_BANNERS','banners');



define('TBL_MAIL_TEMPLATES','mail_templates');
define('TBL_ORDERS','orders');
define('TBL_NEWS','news');
define('TBL_REVIEW','review');
define('TBL_ATTRIBUTES','attributes');
define('TBL_CART_ORDER','cart_order');
define('TBL_CART_TRANSACTIONS','cart_transcation');
define('TBL_COUPON','coupon');
define('TBL_GALLERY','gallery');
define('TBL_ALBUMS','albums');
define('TBL_APPLYFORMS','applyforms');
define('TBL_DIRECTORIES','directories');
define('TBL_BLOGCOMMENTS','blog_comments');
define('ADMINROOT','administrator');



/********* END  Table Names *********/


define('STR_TO_TIME',strtotime(date("Y-m-d H:i:s")));

define('ONLY_DATE',date("m-d-Y"));

define('DATE_TIME',date("m-d-Y H:i:s"));

define('DATE_TIME_FORMAT',date("l dS F Y, H:i:s A", STR_TO_TIME));

define('DATETIMEFORMAT',date("l-dS-F-Y-H-i-s-A", STR_TO_TIME));

define('DBIN','INSERT INTO ');

define('DBUP','UPDATE ');

define('DBWHR',' WHERE ');

define('DBDEL','DELETE ');

define('DBFROM',' FROM ');

define('DBSELECT',' SELECT ');

define('DBSET',' SET ');

define('HEAD_LTN','location:');

define('DB_LMT',' LIMIT ');

define('DB_ORDER',' ORDER BY ');

define('DB_LIKE',' LIKE ');
###################################################################

######### Physical Path Constants 

###################################################################

//define(SITEROOT, 				$_SERVER['DOCUMENT_ROOT']."/beta");

define('SITEROOT', 				$_SERVER['DOCUMENT_ROOT']."/jamadagni/new_admin/");

/*define(LISTINGIMAGESROOT, 		SITEROOT."/images/listings");

define(UPLOADSROOT, 			SITEROOT."/uploads/");

define(USER_IMAGE_ROOT,	        SITEROOT."/images/");

*/

###################################################################

######### Url Constants 

###################################################################

//define(SITEURL, 				"http://".$_SERVER['HTTP_HOST']);

define('SITEURL', 				"http://".$_SERVER['HTTP_HOST']."/jamadagni/new_admin/");



//define(SITEPATH_URL,'http://'.$_SERVER['HTTP_HOST']);

?>


