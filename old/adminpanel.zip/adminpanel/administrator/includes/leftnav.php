<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li <?php if($option=='com_dashboard'){echo 'class="active"';} ?>><a href="index.php?option=com_dashboard"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
						
						<li>
							<a href="#" class="dropmenu"> <i class="icon-edit"></i><span class="hidden-tablet">Users</span></a>
							<ul <?php if($option=='com_adminlist'||$option=='com_adminlist_insert') ?>>
								<li  <?php if($option=='com_adminlist'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_adminlist"><i class="icon-file-alt"></i><span class="hidden-tablet">Admin Users</span></a></li>
								<li <?php if($option=='com_adminlist_insert'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_regusers"><i class="icon-file-alt"></i><span class="hidden-tablet">Registered Users</span></a></li>

							</ul>	
						</li>
						
						
						<li>
							<a href="#"  class="dropmenu"><i class="icon-tasks"></i><span class="hidden-tablet"> Pages</span></a>
								<ul  <?php if($option=='com_aboutus'||$option=='com_videos'||$option=='com_videos_insert'||$option=='com_privacypolicy'||$option=='com_conditions') ?>>
									<li  <?php if($option=='com_aboutus'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_aboutus"><i class="icon-file-alt"></i><span class="hidden-tablet">About Us</span></a></li>
									<li <?php if($option=='com_complaints'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_complaints"><i class="icon-file-alt"></i><span class="hidden-tablet">Complaints</span></a></li>
									<li <?php if($option=='com_videos'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_videos"><i class="icon-file-alt"></i><span class="hidden-tablet">videos</span></a></li>
									<li  <?php if($option=='com_privacypolicy'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_privacypolicy"><i class="icon-file-alt"></i><span class="hidden-tablet">privacy Policy</span></a></li>
									<li <?php if($option=='com_conditions'){echo 'class="active"';} ?>><a class="submenu" href="index.php?option=com_conditions"><i class="icon-file-alt"></i><span class="hidden-tablet">Terms and Conditions</span></a></li>


								</ul>	
							
							
						</li>
						
						
						<li>
							<a href="index.php?option=com_news"> <i class="icon-edit"></i><span class="hidden-tablet">News</span></a>		
						</li>
						
						<li>
							<a href="index.php?option=com_banners"><i class="icon-edit"></i><span class="hidden-tablet">Banners</span></a>		
						</li>
						
					<!--	<li>
							<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Dropdown</span><span class="label label-important"> 3 </span></a>
							<ul>
								<li><a class="submenu" href="submenu.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 1</span></a></li>
								<li><a class="submenu" href="submenu2.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 2</span></a></li>
								<li><a class="submenu" href="submenu3.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 3</span></a></li>
							</ul>	
						</li>
						
						
						<li><a href="chart.php"><i class="icon-list-alt"></i><span class="hidden-tablet"> Charts</span></a></li>
						
						<li><a href="gallery.html"><i class="icon-picture"></i><span class="hidden-tablet"> Gallery</span></a></li>
						<li><a href="tables.php"><i class="icon-align-justify"></i><span class="hidden-tablet"> Tables</span></a></li>
						<li><a href="calendar.html"><i class="icon-calendar"></i><span class="hidden-tablet"> Calendar</span></a></li>
						<li><a href="file-manager.html"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
						<li><a href="icon.html"><i class="icon-star"></i><span class="hidden-tablet"> Icons</span></a></li>
						<li><a href="../../index.php"><i class="icon-lock"></i><span class="hidden-tablet"> Login Page</span></a></li>-->
					</ul>
				</div>
			</div>
