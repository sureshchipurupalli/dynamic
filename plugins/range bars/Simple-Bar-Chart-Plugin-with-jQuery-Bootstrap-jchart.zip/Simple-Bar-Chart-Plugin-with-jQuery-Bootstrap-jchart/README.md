jchart
======

JQuery Charting Plugin

You can view the documentation and a demo of the application at http://www.requireonce.com/jchart/demo.html
