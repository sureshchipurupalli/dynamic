A Pen created at CodePen.io. You can find this one at http://codepen.io/valencia123/pen/aOopQx.

 animated progress-bar with boostrap tooltip on it, 