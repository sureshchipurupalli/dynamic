A Pen created at CodePen.io. You can find this one at http://codepen.io/thathurtabit/pen/ymECf.

 This progress bar uses the HTML5 custom data-* attribute to allow for quick updating to a progress bar animated by Zepto (or jQuery). The animation is wrapped in a window.resize function to reanimate if the browser size is changed.