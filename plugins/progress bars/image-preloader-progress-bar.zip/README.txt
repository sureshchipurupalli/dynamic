A Pen created at CodePen.io. You can find this one at http://codepen.io/MrHill/pen/avKfz.

 Progress bar with changeable skins showing page load percentage